// Open envelope function
function openEnvelope(id) {
    const envelope = document.getElementById(id);
    envelope.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // Prevent scrolling

    // 🟢 Play video if found inside envelope
    const video = envelope.querySelector('video');
    if (video) {
        video.currentTime = 0;
        video.play();
    }
}

// Close envelope function
function closeEnvelope(id) {
    const envelope = document.getElementById(id);
    envelope.style.display = 'none';
    document.body.style.overflow = 'auto'; // Re-enable scrolling

    // 🔴 Pause and reset video
    const video = envelope.querySelector('video');
    if (video) {
        video.pause();
        video.currentTime = 0;
    }
}

// Play song from hidden heart
let heartClicks = 0;
const heartMessages = [
    "Playing our song...",
    "Still waiting for that hoodie back... just kidding!",
    "You've found all my secrets!"
];

function playSong() {
    heartClicks++;
    
    const heart = document.querySelector('.hidden-heart');
    const audio = new Audio('media/our-song.mp4');
    
    if (heartClicks === 1) {
        // First click: Play song
        audio.play();
        heart.textContent = '🎵';
        heart.style.animation = 'none';
        setTimeout(() => {
            heart.style.animation = 'pulse 2s infinite';
            heart.textContent = '❤️';
        }, 3000);
        alert(heartMessages[0]);
    } else if (heartClicks === 2) {
        // Second click: Show message
        alert(heartMessages[1]);
        heart.textContent = '👕';
        setTimeout(() => {
            heart.textContent = '❤️';
        }, 2000);
    } else if (heartClicks >= 3) {
        // Third click: Reset
        alert(heartMessages[2]);
        heartClicks = 0;
        heart.textContent = '❤️';
    }
}

// Close envelope when clicking outside content
document.addEventListener('click', function(event) {
    const envelopes = document.querySelectorAll('.envelope-content');
    envelopes.forEach(envelope => {
        if (event.target === envelope) {
            closeEnvelope(envelope.id);
        }
    });
});